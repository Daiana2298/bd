﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace studentDB
{
    public partial class Form1 : Form
    {

        public string sqlCon = "Data Source=DESKTOP-F7U9QJ9\\SQLEXPRESS;Initial Catalog=proiect;Integrated Security=True";
        SqlConnection con;
        SqlDataAdapter sda;
        DataTable dbdataset;
        public Form1()
        {
            InitializeComponent();
        }
       
        private void Form1_Load(object sender, EventArgs e)
        {
            con = new SqlConnection(sqlCon);
            con.Open();
            DataTable dt = con.GetSchema("Tables");
            foreach (DataRow row in dt.Rows)
            {
                string tablename = (string)row[2];
                ToolStripMenuItem table = new ToolStripMenuItem();
                table.Click += new EventHandler(menu_Click);
                table.Text = tablename;
                toolStripDropDownButton1.DropDown.Items.Add(table);
            }
        }
        void menu_Click(object sender, EventArgs e)
        {
            var menuItem = sender as ToolStripMenuItem;
            var menuText = menuItem.Text;
            getTableContent(menuText);
           
        }
        void getTableContent (String tableName)
        {
            button1.Visible = true;
            dataGridView1.Visible = true;
            SqlCommand cmdDB = new SqlCommand ("select * from " + tableName + " ; ", con);
            try
            {
                 sda = new SqlDataAdapter(cmdDB);
                dbdataset = new DataTable();
                sda.Fill(dbdataset);
           
                dataGridView1.DataSource = dbdataset;
                sda.Update(dbdataset);
            } catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
            private void toolStripDropDownButton1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            dataGridView1.EndEdit(); //very important step

            try {
                sda.Update(dbdataset);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            MessageBox.Show("Updated");
        }
    }
}
